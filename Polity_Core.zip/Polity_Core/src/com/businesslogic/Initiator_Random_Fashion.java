package com.businesslogic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.data.*;
import com.util.Random_Generation;

public class Initiator_Random_Fashion  implements Initiator{

	Random_Generation objRandom_Generation = new Random_Generation();
	Election objElection ;
	Group objGroup;
	
	

	
	@Override
	public List<Issue> initiate_issue() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booth initiate_booth() {

		 String booth_ID=objRandom_Generation.generate_random_String_with_prefix(objProject_Variables.Booth_ID_FORMAT, objProject_Variables.RANDOM_LENGTH);
		 String booth_name=objRandom_Generation.generate_random_String_with_prefix(objProject_Variables.Booth_NAME_FORMAT, objProject_Variables.RANDOM_LENGTH);
		 int booth_numberOfElectorate=objRandom_Generation.generate_random_int(objProject_Variables.ELECTORATE_PER_BOOTH_MIN,objProject_Variables.ELECTORATE_PER_BOOTH_MAX);
		 int booth_polled_vote=0;
		 List<Double> booth_casteDist=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_CASTE);
		 List<Double> booth_groupBias=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_GROUP);
		 List<Double> booth_polityBias=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_PARTY);;
		 List<Double> booth_candidateBias=null;
		 List<Double> booth_issueBias=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_ISSUE);
		 List<Double> booth_otherBias=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_OTHERBIASES);
		 List<Double> booth_profile=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_PROFILE);
		 double booth_area_sqKM=objRandom_Generation.generate_random_double(objProject_Variables.BOOTH_AREA_SQKM_MIN,objProject_Variables.BOOTH_AREA_SQKM_MAX);
		 int booth_geo_coordinate_x=0;
		 int booth_geo_coordinate_y=0;
		 int booth_geo_code=0;
		 double booth_historical_polling_percentage=objRandom_Generation.generate_random_double(objProject_Variables.HIST_POLLING_MIN,objProject_Variables.HIST_POLLING_MAX);
		
		
		return new Booth( booth_ID,  booth_name,  booth_numberOfElectorate,  booth_polled_vote,
				 booth_casteDist,  booth_polityBias,   booth_candidateBias,
				 booth_issueBias,   booth_otherBias,  booth_profile,
				 booth_area_sqKM,  booth_geo_coordinate_x,  booth_geo_coordinate_y,  booth_geo_code,
				 booth_historical_polling_percentage,booth_groupBias);
	}

	@Override
	public List<Group> initiate_group(List<Party> lst_party) {
		String group_ID;
		String group_name;
		double group_relevance;
		HashMap<Party,Double> group_support_to_party;
		double group_unity_factor;
		double group_vocal_level;
		
		List<Group> lst_group= new ArrayList<Group>();
		for(int i=0;i <objProject_Variables.TOTAL_GROUP;i++) {
			group_ID=objRandom_Generation.generate_random_String_with_prefix(objProject_Variables.GROUP_ID_FORMAT, objProject_Variables.RANDOM_LENGTH);
			group_name=objRandom_Generation.generate_random_String_with_prefix(objProject_Variables.GROUP_NAME_FORMAT, objProject_Variables.RANDOM_LENGTH);
			group_relevance=objRandom_Generation.generate_random_double(objProject_Variables.GROUP_RELEVANCE_MIN, objProject_Variables.GROUP_RELEVANCE_MAX);
			group_support_to_party=this.populate_party_bias(lst_party);
			group_unity_factor=objRandom_Generation.generate_random_double(objProject_Variables.GROUP_UNITY_FACTOR_MIN, objProject_Variables.GROUP_UNITY_FACTOR_MAX);
			group_vocal_level=objRandom_Generation.generate_random_double(objProject_Variables.GROUP_VOCAL_LEVEL_MIN, objProject_Variables.GROUP_VOCAL_LEVEL_MAX);
			
			objGroup= new Group(group_ID, group_name, group_relevance, group_support_to_party, group_unity_factor, group_vocal_level);
			lst_group.add(objGroup);
		}
		
		return lst_group;
	}

	@Override
	public List<Electorate_Profile> initiate_profile() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Candidate> initiate_candidate() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	public HashMap<Party,Double> populate_party_bias(List<Party> lst){
		HashMap<Party,Double> map_generic= new HashMap<Party,Double>();
		int index=0;
		for (double item:objRandom_Generation.distribute_randomly_decimal(0,100)) {
			map_generic.put(lst.get(index++),Double.valueOf(item));
		}
		return map_generic;
	}
	
	
	
	@Override
	public void initiate_election_commission(Election_Commission objEC) {
		objEC.setElection_commission_name(objProject_Variables.EC_NAME);
	}
	
	
	@Override
	public Election initiate_election() {
		
		String election_ID=objRandom_Generation.generate_random_String_with_prefix(objProject_Variables.ELECTION_ID_FORMAT, objProject_Variables.RANDOM_LENGTH);
		String election_name=objRandom_Generation.generate_random_String_with_prefix(objProject_Variables.ELECTION_NAME_FORMAT, objProject_Variables.RANDOM_LENGTH);
		String election_type=objProject_Variables.ELECTION_TYPE;
		int election_seats=objProject_Variables.TOTAL_CONSTITUENCY;
		List<Constituency> election_constituency=this.initiate_constituency(election_seats);
		
		objElection = new Election(election_ID,election_name,election_type,election_seats,election_constituency);
		
		return objElection;
	}
	
	
	@Override
	public List<Constituency> initiate_constituency(int noOfConstituency) {
		Constituency const_obj=null;
		
		int constituency_ID;
		String constituency_name;
		int constituency_total_voter;
		int constituency_total_polled_vote;
		int constituency_total_booth;
		
		List<Booth> constituency_booth_list=null;
		List<Double> constituency_polityBias=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_PARTY);
		List<Double> constituency_candidateBias=null;
		List<Double> constituency_issueBias=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_ISSUE);
		List<Double> constituency_otherBias=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_OTHERBIASES);
		List<Double> constituency_profile=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_PROFILE);
		List<Double> constituency_past_result_bias=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_PARTY);
		int constituency_geo_code=0;
		
		List<Constituency> lst_const = new ArrayList<Constituency>();
		for(int i=0;i <objProject_Variables.TOTAL_CONSTITUENCY;i++) {
			
			constituency_ID=i;
			constituency_name=objRandom_Generation.generate_random_String_with_prefix(objProject_Variables.ELECTION_TYPE+"_Name_", objProject_Variables.RANDOM_LENGTH);
			constituency_total_voter=0;//this will be populated after booth formation
			constituency_total_polled_vote=0; //this will be populated during voting
			constituency_total_booth=objRandom_Generation.generate_random_int(objProject_Variables.CONS_MIN_BOOTH, objProject_Variables.CONS_MAX_BOOH);
			
			const_obj=new Constituency(constituency_ID, constituency_name, constituency_total_voter,
					constituency_total_polled_vote, constituency_total_booth, 
					constituency_booth_list, constituency_polityBias, constituency_candidateBias, 
					constituency_issueBias, constituency_otherBias, constituency_profile, 
					constituency_past_result_bias, constituency_geo_code);

			lst_const.add(const_obj);
			
		}
		
		
		return lst_const;
	}

	
	@Override
	public List<Party> initiate_party_list() {
		
		String party_name;
		String party_symbol;
		String party_id;
		double party_acceptibility;
		double party_image;
		double party_financial_power;
		double party_campaign_power;
		double party_luck_factor;
		double party_past_results;
		
		List<Double> party_pro_Issues;
		List<Double> party_pro_castes;
		List<Double> party_pro_groups;
		List<Double> party_support_profile;
		
		List<Party> lst_party = new ArrayList<Party>();
		for(int i=0;i <objProject_Variables.TOTAL_PARTY;i++) {
			party_id=objRandom_Generation.generate_random_String_with_prefix(objProject_Variables.PARTY_ID_FORMAT, objProject_Variables.RANDOM_LENGTH);
			party_name = objRandom_Generation.generate_random_non_numeric_String_with_prefix(objProject_Variables.PARTY_NAME_FORMAT, 5);
			party_symbol=objRandom_Generation.getSymbol(i);
			party_acceptibility=objRandom_Generation.generate_random_double(objProject_Variables.PARTY_PARAM_MIN, objProject_Variables.PARTY_PARAM_MAX);
			party_image=objRandom_Generation.generate_random_double(objProject_Variables.PARTY_PARAM_MIN, objProject_Variables.PARTY_PARAM_MAX);
			party_financial_power=objRandom_Generation.generate_random_double(objProject_Variables.PARTY_PARAM_MIN, objProject_Variables.PARTY_PARAM_MAX);
			party_campaign_power=objRandom_Generation.generate_random_double(objProject_Variables.PARTY_PARAM_MIN, objProject_Variables.PARTY_PARAM_MAX);
			party_luck_factor=objRandom_Generation.generate_random_double(objProject_Variables.PARTY_PARAM_MIN, objProject_Variables.PARTY_PARAM_MAX);
			party_past_results=objRandom_Generation.generate_random_double(objProject_Variables.PARTY_PARAM_MIN, objProject_Variables.PARTY_PARAM_MAX);

			party_pro_Issues=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_ISSUE);
			party_pro_castes=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_CASTE);
			party_pro_groups=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_GROUP);
			party_support_profile=objRandom_Generation.populate_bias(objProject_Variables.TOTAL_PROFILE);
			
			
			lst_party.add(new Party(party_id,party_name,party_symbol,party_acceptibility,party_image,party_financial_power,party_campaign_power,party_luck_factor,party_past_results,party_pro_Issues,party_pro_castes,party_pro_groups,party_support_profile));
		}
		
		return lst_party;
	}
	
	
	
}
