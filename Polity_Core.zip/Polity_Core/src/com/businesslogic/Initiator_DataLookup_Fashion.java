package com.businesslogic;

import java.util.List;

import com.data.*;

public abstract class Initiator_DataLookup_Fashion implements Initiator{

	
	}


