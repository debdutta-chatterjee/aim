package com.businesslogic;

import java.util.List;

import com.data.Election;
import com.data.Election_Commission;
import com.data.Party;

public class Console_Output {

	public void print_console_EC(Election_Commission objEC){
		System.out.println("EC "+objEC.getElection_commission_name()+" has started functioning for the next poll.") ;
	}

	public void print_console_Election(Election objElection) {
		String id=objElection.getElection_ID();
		String name=objElection.getElection_name();
		String type=objElection.getElection_type();
		int seats=objElection.getElection_seats();
		System.out.println("Election Commission has announced "+type+" poll of ["+name+"] for ["+seats+"] seats.");
	}
	
	
	public void print_console_party_list(List<Party> lst_Party) {
		for(Party objParty:lst_Party) {
			System.out.println(objParty);
		}
	}
	
}
