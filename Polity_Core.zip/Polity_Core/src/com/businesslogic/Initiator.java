package com.businesslogic;

import java.util.List;

import com.data.*;
import com.variables.Project_Variables;


public interface Initiator {
	
	Project_Variables objProject_Variables= new Project_Variables();
	
	public void initiate_election_commission(Election_Commission objEC);
	public List<Party> initiate_party_list();
	public List<Constituency> initiate_constituency(int noOfConstituency);
	public List<Issue> initiate_issue();
	public Booth initiate_booth();
	public List<Group> initiate_group(List<Party> lst_party);
	
	public List<Electorate_Profile> initiate_profile();
	public List<Candidate> initiate_candidate();
	public Election initiate_election();
}
