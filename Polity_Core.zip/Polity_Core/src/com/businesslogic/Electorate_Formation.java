package com.businesslogic;

import java.util.List;

public class Electorate_Formation {
	public int getElectorateSize(int min,int max) {return 0;}
	public List<Double> getElectorateBias(int numOfCandidate) {return null;}
}
