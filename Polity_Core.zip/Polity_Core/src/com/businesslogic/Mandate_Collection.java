package com.businesslogic;

import java.util.List;

import com.data.Booth;
import com.data.Constituency;
import com.util.Random_Generation;
import com.variables.Project_Variables;



public class Mandate_Collection {

	Random_Generation objRandom_Generation = new Random_Generation();
	Project_Variables objProject_Variables= new Project_Variables();
	
	public List<Integer> getMandate(int numberOfCandidate, int totalElectorate, int totalPolled,List<Double> biasFactor,int randomLevel) {return null;}


	public void election_mandate(List<Constituency> lst_const) {
		int polledvote=0;
		
		for(Constituency const_obj:lst_const) {
			polledvote=0;
			
			for(Booth booth_obj:const_obj.getConstituency_booth_list()) {
				polledvote=this.getPolledVote(booth_obj.getBooth_numberOfElectorate(),booth_obj.getBooth_groupBias(),
						booth_obj.getBooth_casteDist(),booth_obj.getBooth_polityBias(),booth_obj.getBooth_candidateBias(),
						booth_obj.getBooth_issueBias(),booth_obj.getBooth_otherBias(),
						booth_obj.getBooth_profile(),booth_obj.getBooth_historical_polling_percentage()
						);
				
				booth_obj.setBooth_polled_vote(polledvote);
				booth_obj.setParty_polled_vote(this.getDistributed_vote(booth_obj.getBooth_polled_vote(), objProject_Variables.TOTAL_PARTY));
				//System.out.println(booth_obj.getParty_polled_vote().size());
			}
			const_obj.calculate_total_polled_voter();
			const_obj.calculate_party_votes();
			polledvote=0;
		}
	}

	
	public List<Integer> getDistributed_vote(int polled_vote,int total_party){
//		System.out.println(objRandom_Generation.populate_bias(total_party));
		return objRandom_Generation.distribute_randomly_integer(polled_vote,total_party,objRandom_Generation.populate_bias(total_party));
	}
	
	
	
	
	public int getPolledVote(int total_vote,List<Double> booth_groupBias,
			List<Double> booth_casteDist,List<Double> booth_polityBias,List<Double> booth_candidateBias,
			List<Double> booth_issueBias,List<Double> booth_otherBias,
			List<Double> booth_profile,double booth_historical_polling_percentage) {
		
		double current_poll_percent=0;
		double variance=objRandom_Generation.generate_random_double(objProject_Variables.HIST_POLLING_VARIANCE_MIN,objProject_Variables.HIST_POLLING_VARIANCE_MAX);
		
		
		//System.out.println("TOTAL: "+total_vote);
		//System.out.println("VARIANCE: "+variance);
		
		current_poll_percent=booth_historical_polling_percentage+variance;
		current_poll_percent=Math.round(current_poll_percent);
		//System.out.println("Current %:"+current_poll_percent);
		if(current_poll_percent>99){
			current_poll_percent=98;
		}
		
		int polled=(int) (total_vote*current_poll_percent/100);
		//System.out.println("POLLED:"+polled);
		
		return polled;
	}
	
	int get_polling_percent_factor(List<Double> booth_groupBias,
			List<Double> booth_casteDist,List<Double> booth_polityBias,List<Double> booth_candidateBias,
			List<Double> booth_issueBias,List<Double> booth_otherBias,
			List<Double> booth_profile) {
		return 6;
	}
	

}
