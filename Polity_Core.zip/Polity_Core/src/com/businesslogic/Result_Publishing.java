package com.businesslogic;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.data.Constituency;
import com.data.Election;
import com.data.Party;

public class Result_Publishing {
	public void publish_result_console() {} //List<Constituency_Result>
	public void publish_result_json() {}
	public void publish_result_csv() {}
	public void publish_result_xml() {}
	
	
	public String simple_console_output(Object obj) {
		return ReflectionToStringBuilder.toString(obj, ToStringStyle.SHORT_PREFIX_STYLE);
		//.split("@")[1]
	}
	
	public void printElectionDetails(Election election_obj) {
		
		System.out.println("election_ID:"+election_obj.getElection_ID());
		System.out.println("election_name:"+election_obj.getElection_ID());
		System.out.println("election_type:"+election_obj.getElection_type());
		System.out.println("election_seats:"+election_obj.getElection_seats());
		System.out.println("*********************************************");
		
		Party p;
		Integer vote=0;
		int party_position=0;
		double vote_percent=0;
		for(Constituency cons_obj:election_obj.getElection_constituency()) {
			System.out.println("Constituency ID:"+cons_obj.getConstituency_ID());
			System.out.println("Total Booth:"+cons_obj.getConstituency_total_booth());
			System.out.println("Historical Poll %:"+cons_obj.get_const_hist_poll_percent());
			System.out.println("Total Voter:"+cons_obj.getConstituency_total_voter());
			System.out.println("Polled Vote:"+cons_obj.getConstituency_total_polled_vote());
			System.out.println("Polled %:"+Math.round((double)cons_obj.getConstituency_total_polled_vote()/(double)cons_obj.getConstituency_total_voter()*100)+"%");
			//System.out.println();
			
			HashMap<Party,Integer> map_party_wise_vote=cons_obj.getParty_wise_const_party_polled_vote();

			vote=0;
			party_position=0;
			vote_percent=0;
			for (Entry<Party, Integer> entry : map_party_wise_vote.entrySet()) {
	            p= entry.getKey() ;
				vote = entry.getValue();
				vote_percent=Math.round((double)vote.intValue()/cons_obj.getConstituency_total_polled_vote()*100);
				System.out.println(++party_position+". "+ p.getParty_name()+":["+vote.intValue()+ "] vote%:"+vote_percent+"%");
	    }
			System.out.println("*********************************************");
		
		}
		System.out.println("*********************************************");
	}
	
}
