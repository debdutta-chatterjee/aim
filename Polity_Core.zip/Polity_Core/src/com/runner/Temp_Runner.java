package com.runner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.businesslogic.Console_Output;
import com.businesslogic.Initiator;
import com.businesslogic.Initiator_Random_Fashion;
import com.businesslogic.Mandate_Collection;
import com.businesslogic.Result_Publishing;
import com.data.Booth;
import com.data.Constituency;
import com.data.Election;
import com.data.Election_Commission;
import com.data.Party;
import com.util.Random_Generation;

public class Temp_Runner {

	public static void a_main(String[] args) {
		
		//Initiator
		Initiator objInitiator = new Initiator_Random_Fashion();
		Result_Publishing objResult_Publishing = new Result_Publishing();
		Console_Output objConsole = new Console_Output();
		
		//EC starts functioning
		Election_Commission objEC= new Election_Commission(objInitiator);
		objConsole.print_console_EC(objEC);
				
		//EC announces election
		Election objElection = objEC.announce_election();
		objConsole.print_console_Election(objElection);
		
		//Participating Polity parties
		List<Party> list_party=objEC.get_party_details();
		objConsole.print_console_party_list(list_party);
		
	}
	
	
	public static void b_main(String[] args) {
		Initiator objInitiator = new Initiator_Random_Fashion();
		//Booth b=objInitiator.initiate_booth();
		//System.out.println(b);
		
		//objInitiator.initiate_constituency(TOTAL_CONSTITUENCY);
		
	}
	
	public static void main(String[] args) {
		
		//Initiator
		Initiator objInitiator = new Initiator_Random_Fashion();
		Result_Publishing objResult_Publishing = new Result_Publishing();
		Console_Output objConsole = new Console_Output();
		
		//EC starts functioning
		Election_Commission objEC= new Election_Commission(objInitiator);
		objConsole.print_console_EC(objEC);
				
		//EC announces election
		Election objElection = objEC.announce_election();
		objConsole.print_console_Election(objElection);
		
		//Participating Polity parties
		List<Party> list_party=objEC.get_party_details();
		//objConsole.print_console_party_list(list_party);
		
		//Constituency
		List<Constituency> const_list_obj=objInitiator.initiate_constituency(objElection.getElection_seats());
		//System.out.println(const_list_obj);
		objElection.setElection_constituency(const_list_obj);
		
		//mandate
		objElection.mandate_collection();
		objElection.consolidate_results_partywise(list_party);
		objResult_Publishing.printElectionDetails(objElection);
	}
	
}
