package com.data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.businesslogic.Initiator;
import com.businesslogic.Initiator_Random_Fashion;
import com.util.Calculations_Util;
import com.variables.Project_Variables;

import lombok.ToString;

@ToString
public class Constituency {
	
	Initiator objInitiator = new Initiator_Random_Fashion();
	Calculations_Util cal_obj= new Calculations_Util();
	Project_Variables obj_proj_var= new Project_Variables();
	
	private int constituency_ID;
	private String constituency_name;
	private int constituency_total_voter;
	private int constituency_total_polled_vote;
	private int constituency_total_booth;
	private List<Booth> constituency_booth_list;
	private List<Double> constituency_polityBias;
	private List<Double> constituency_candidateBias;
	private List<Double> constituency_issueBias;
	private List<Double> constituency_otherBias;
	private List<Double> constituency_profile;
	private List<Double> constituency_past_result_bias;
	private int constituency_geo_code;
	private List<Integer> const_party_polled_vote;
	private HashMap<Party,Integer> party_wise_const_party_polled_vote;
	
	private Party winner;
	private Party runnerup;
	private Party runnerup_2;
	private int margin;
	
	
	public Constituency(int constituency_ID, String constituency_name, int constituency_total_voter,
			int constituency_total_polled_vote, int constituency_total_booth, List<Booth> constituency_booth_list,
			List<Double> constituency_polityBias, List<Double> constituency_candidateBias,
			List<Double> constituency_issueBias, List<Double> constituency_otherBias, List<Double> constituency_profile,
			List<Double> constituency_past_result_bias, int constituency_geo_code) {
		super();
		this.constituency_ID = constituency_ID;
		this.constituency_name = constituency_name;
		this.constituency_total_voter = constituency_total_voter;
		this.constituency_total_polled_vote = constituency_total_polled_vote;
		this.constituency_total_booth = constituency_total_booth;
		this.constituency_booth_list = constituency_booth_list;
		this.constituency_polityBias = constituency_polityBias;
		this.constituency_candidateBias = constituency_candidateBias;
		this.constituency_issueBias = constituency_issueBias;
		this.constituency_otherBias = constituency_otherBias;
		this.constituency_profile = constituency_profile;
		this.constituency_past_result_bias = constituency_past_result_bias;
		this.constituency_geo_code = constituency_geo_code;
		
		this.populate_booth_for_constituency(constituency_total_booth);
		this.calculate_total_voter();
	}
	
	
	private void populate_booth_for_constituency(int total_booth) {
		Booth booth_obj=null;
		this.constituency_booth_list= new ArrayList<Booth>();
		
		for(int i=0;i<total_booth-1;i++) {
			booth_obj= objInitiator.initiate_booth();
			this.constituency_booth_list.add(booth_obj);
		}
		
	}
	
	
	private void calculate_total_voter() {
		for(Booth b:this.constituency_booth_list) {
			constituency_total_voter=constituency_total_voter+b.getBooth_numberOfElectorate();
		}
	}
	
	
	public void calculate_party_votes() {
		
		int[] arr_vote= new int[obj_proj_var.TOTAL_PARTY];
		
		for(Booth b:this.constituency_booth_list) {
			//System.out.println(b.party_polled_vote.size());
			for(int index=0;index<obj_proj_var.TOTAL_PARTY;index++) {
				arr_vote[index]=arr_vote[index]+b.party_polled_vote.get(index);
			}
		}
		const_party_polled_vote = Arrays.stream(arr_vote).boxed().collect(Collectors.toList());
		//System.out.println(const_party_polled_vote);
	}
	
	
	
	
	
	
	public void calculate_total_polled_voter() {
		int polledvote=0;
		for(Booth b:this.constituency_booth_list) {
			polledvote=polledvote+b.getBooth_polled_vote();
		}
		constituency_total_polled_vote=polledvote;
	}
	
	
	public double get_const_hist_poll_percent() {
		double hist_percent=0;
		for(Booth b:this.constituency_booth_list) {
			hist_percent=hist_percent+b.getBooth_historical_polling_percentage();
		}
		hist_percent=hist_percent/this.constituency_booth_list.size();
		return Math.round(hist_percent);
	}
	
	
	public void results_calculations() {
		
		 
		
	}
	
	
	
	
	
	
	public int getConstituency_ID() {
		return constituency_ID;
	}
	public void setConstituency_ID(int constituency_ID) {
		this.constituency_ID = constituency_ID;
	}
	public String getConstituency_name() {
		return constituency_name;
	}
	public void setConstituency_name(String constituency_name) {
		this.constituency_name = constituency_name;
	}
	public int getConstituency_total_voter() {
		return constituency_total_voter;
	}
	public void setConstituency_total_voter(int constituency_total_voter) {
		this.constituency_total_voter = constituency_total_voter;
	}
	public int getConstituency_total_polled_vote() {
		return constituency_total_polled_vote;
	}
	public void setConstituency_total_polled_vote(int constituency_total_polled_vote) {
		this.constituency_total_polled_vote = constituency_total_polled_vote;
	}
	public int getConstituency_total_booth() {
		return constituency_total_booth;
	}
	public void setConstituency_total_booth(int constituency_total_booth) {
		this.constituency_total_booth = constituency_total_booth;
	}
	public List<Booth> getConstituency_booth_list() {
		return constituency_booth_list;
	}
	public void setConstituency_booth_list(List<Booth> constituency_booth_list) {
		this.constituency_booth_list = constituency_booth_list;
	}
	public List<Double> getConstituency_polityBias() {
		return constituency_polityBias;
	}
	public void setConstituency_polityBias(List<Double> constituency_polityBias) {
		this.constituency_polityBias = constituency_polityBias;
	}
	public List<Double> getConstituency_candidateBias() {
		return constituency_candidateBias;
	}
	public void setConstituency_candidateBias(List<Double> constituency_candidateBias) {
		this.constituency_candidateBias = constituency_candidateBias;
	}
	public List<Double> getConstituency_issueBias() {
		return constituency_issueBias;
	}
	public void setConstituency_issueBias(List<Double> constituency_issueBias) {
		this.constituency_issueBias = constituency_issueBias;
	}
	public List<Double> getConstituency_otherBias() {
		return constituency_otherBias;
	}
	public void setConstituency_otherBias(List<Double> constituency_otherBias) {
		this.constituency_otherBias = constituency_otherBias;
	}
	public List<Double> getConstituency_profile() {
		return constituency_profile;
	}
	public void setConstituency_profile(List<Double> constituency_profile) {
		this.constituency_profile = constituency_profile;
	}
	public List<Double> getConstituency_past_result_bias() {
		return constituency_past_result_bias;
	}
	public void setConstituency_past_result_bias(List<Double> constituency_past_result_bias) {
		this.constituency_past_result_bias = constituency_past_result_bias;
	}
	public int getConstituency_geo_code() {
		return constituency_geo_code;
	}
	public void setConstituency_geo_code(int constituency_geo_code) {
		this.constituency_geo_code = constituency_geo_code;
	}


	public List<Integer> getConst_party_polled_vote() {
		return const_party_polled_vote;
	}


	public void setConst_party_polled_vote(List<Integer> const_party_polled_vote) {
		this.const_party_polled_vote = const_party_polled_vote;
	}


	public HashMap<Party, Integer> getParty_wise_const_party_polled_vote() {
		return party_wise_const_party_polled_vote;
	}


	public void setParty_wise_const_party_polled_vote(List<Party> party_lst) {
		this.party_wise_const_party_polled_vote =cal_obj.get_party_wise_results(party_lst, const_party_polled_vote);
	}


	public Party getWinner() {
		return winner;
	}


	public void setWinner(Party winner) {
		this.winner = winner;
	}


	public Party getRunnerup() {
		return runnerup;
	}


	public void setRunnerup(Party runnerup) {
		this.runnerup = runnerup;
	}


	public Party getRunnerup_2() {
		return runnerup_2;
	}


	public void setRunnerup_2(Party runnerup_2) {
		this.runnerup_2 = runnerup_2;
	}


	public int getMargin() {
		return margin;
	}


	public void setMargin(int margin) {
		this.margin = margin;
	}
	
}
