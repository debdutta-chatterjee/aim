package com.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.ToString;

@ToString
public class Booth {
	private String booth_ID;
	private String booth_name;
	private int booth_numberOfElectorate;
	private int booth_polled_vote;
	private List<Double> booth_groupBias;
	private List<Double> booth_casteDist;
	private List<Double> booth_polityBias;
	private List<Double> booth_candidateBias;
	private List<Double> booth_issueBias;
	private List<Double> booth_otherBias;
	private List<Double> booth_profile;
	private double booth_area_sqKM;
	private int booth_geo_coordinate_x;
	private int booth_geo_coordinate_y;
	private int booth_geo_code;
	private double booth_historical_polling_percentage;
	public List<Integer> party_polled_vote;
	
	
	public Booth(String booth_ID, String booth_name, int booth_numberOfElectorate, int booth_polled_vote,
			List<Double> booth_casteDist, List<Double> booth_polityBias,  List<Double> booth_candidateBias,
			List<Double> booth_issueBias,  List<Double> booth_otherBias, List<Double> booth_profile,
			double booth_area_sqKM, int booth_geo_coordinate_x, int booth_geo_coordinate_y, int booth_geo_code,
			double booth_historical_polling_percentage,List<Double> booth_groupBias) {
		
		this.booth_ID = booth_ID;
		this.booth_name = booth_name;
		this.booth_numberOfElectorate = booth_numberOfElectorate;
		this.booth_polled_vote = booth_polled_vote;
		this.booth_casteDist = booth_casteDist;
		this.booth_polityBias = booth_polityBias;
		this.booth_candidateBias = booth_candidateBias;
		this.booth_issueBias = booth_issueBias;
		this.booth_otherBias = booth_otherBias;
		this.booth_profile = booth_profile;
		this.booth_area_sqKM = booth_area_sqKM;
		this.booth_geo_coordinate_x = booth_geo_coordinate_x;
		this.booth_geo_coordinate_y = booth_geo_coordinate_y;
		this.booth_geo_code = booth_geo_code;
		this.booth_historical_polling_percentage = booth_historical_polling_percentage;
		this.booth_groupBias=booth_groupBias;
	}

	public String getBooth_ID() {
		return booth_ID;
	}


	public void setBooth_ID(String booth_ID) {
		this.booth_ID = booth_ID;
	}


	public String getBooth_name() {
		return booth_name;
	}


	public void setBooth_name(String booth_name) {
		this.booth_name = booth_name;
	}


	public int getBooth_numberOfElectorate() {
		return booth_numberOfElectorate;
	}


	public void setBooth_numberOfElectorate(int booth_numberOfElectorate) {
		this.booth_numberOfElectorate = booth_numberOfElectorate;
	}


	public int getBooth_polled_vote() {
		return booth_polled_vote;
	}


	public void setBooth_polled_vote(int booth_polled_vote) {
		this.booth_polled_vote = booth_polled_vote;
	}


	public List<Double> getBooth_casteDist() {
		return booth_casteDist;
	}


	public void setBooth_casteDist(List<Double> booth_casteDist) {
		this.booth_casteDist = booth_casteDist;
	}


	public List<Double> getBooth_polityBias() {
		return booth_polityBias;
	}


	public void setBooth_polityBias(List<Double> booth_polityBias) {
		this.booth_polityBias = booth_polityBias;
	}


	public List<Double> getBooth_candidateBias() {
		return booth_candidateBias;
	}


	public void setBooth_candidateBias(List<Double> booth_candidateBias) {
		this.booth_candidateBias = booth_candidateBias;
	}


	public List<Double> getBooth_issueBias() {
		return booth_issueBias;
	}


	public void setBooth_issueBias(List<Double> booth_issueBias) {
		this.booth_issueBias = booth_issueBias;
	}


	public List<Double> getBooth_otherBias() {
		return booth_otherBias;
	}


	public void setBooth_otherBias(List<Double> booth_otherBias) {
		this.booth_otherBias = booth_otherBias;
	}


	public List<Double> getBooth_profile() {
		return booth_profile;
	}


	public void setBooth_profile(List<Double> booth_profile) {
		this.booth_profile = booth_profile;
	}


	public double getBooth_area_sqKM() {
		return booth_area_sqKM;
	}


	public void setBooth_area_sqKM(double booth_area_sqKM) {
		this.booth_area_sqKM = booth_area_sqKM;
	}


	public int getBooth_geo_coordinate_x() {
		return booth_geo_coordinate_x;
	}


	public void setBooth_geo_coordinate_x(int booth_geo_coordinate_x) {
		this.booth_geo_coordinate_x = booth_geo_coordinate_x;
	}


	public int getBooth_geo_coordinate_y() {
		return booth_geo_coordinate_y;
	}


	public void setBooth_geo_coordinate_y(int booth_geo_coordinate_y) {
		this.booth_geo_coordinate_y = booth_geo_coordinate_y;
	}


	public int getBooth_geo_code() {
		return booth_geo_code;
	}


	public void setBooth_geo_code(int booth_geo_code) {
		this.booth_geo_code = booth_geo_code;
	}


	public double getBooth_historical_polling_percentage() {
		return booth_historical_polling_percentage;
	}


	public void setBooth_historical_polling_percentage(double booth_historical_polling_percentage) {
		this.booth_historical_polling_percentage = booth_historical_polling_percentage;
	}
	
	
	public List<Double> getBooth_groupBias() {
		return booth_groupBias;
	}

	public void setBooth_groupBias(List<Double> booth_groupBias) {
		this.booth_groupBias = booth_groupBias;
	}

	public List<Integer> getParty_polled_vote() {
		return party_polled_vote;
	}

	public void setParty_polled_vote(List<Integer> party_polled_vote) {
		this.party_polled_vote = party_polled_vote;
	}
	
	}
	
	

