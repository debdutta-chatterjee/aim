package com.data;

import java.util.List;

import com.businesslogic.Mandate_Collection;

import lombok.ToString;

@ToString
public class Election {

	private String election_ID;
	private String election_name;
	private String election_type;
	private int election_seats;
	private List<Constituency> election_constituency;
	
	// add dates - phases -result date
	

	




	public Election(String election_ID,String election_name, String election_type, int election_seats,
			List<Constituency> election_constituency) {
		super();
		this.election_name = election_name;
		this.election_type = election_type;
		this.election_seats = election_seats;
		this.election_constituency = election_constituency;
		this.election_ID = election_ID;
	}

	
	public void mandate_collection() {
		
		Mandate_Collection mand_obj= new Mandate_Collection();
		mand_obj.election_mandate(election_constituency);
	}
	
	
	public void consolidate_results_partywise(List<Party> party_list) {
		
		for(Constituency const_obj:election_constituency) {
			const_obj.setParty_wise_const_party_polled_vote(party_list);
		}
	}
	
	
	public String getElection_ID() {
		return election_ID;
	}

	public void setElection_ID(String election_ID) {
		this.election_ID = election_ID;
	}

	public String getElection_name() {
		return election_name;
	}

	public void setElection_name(String election_name) {
		this.election_name = election_name;
	}

	public String getElection_type() {
		return election_type;
	}

	public void setElection_type(String election_type) {
		this.election_type = election_type;
	}

	public int getElection_seats() {
		return election_seats;
	}

	public void setElection_seats(int election_seats) {
		this.election_seats = election_seats;
	}

	public List<Constituency> getElection_constituency() {
		return election_constituency;
	}

	public void setElection_constituency(List<Constituency> election_constituency) {
		this.election_constituency = election_constituency;
	}

}
