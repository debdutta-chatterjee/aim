package com.data;

import java.util.List;

import com.businesslogic.Initiator;

import lombok.ToString;

@ToString
public class Election_Commission {
	
	Initiator obj_initiator;
	Election obj_election; 
	private List<Party> election_parties;
	
	public Election_Commission(Initiator obj_initiator) {
		this.obj_initiator=obj_initiator;
		obj_initiator.initiate_election_commission(this);
	}
	
	private String election_commission_name;
	public String getElection_commission_name() {
		return election_commission_name;
	}
	public void setElection_commission_name(String election_commission_name) {
		this.election_commission_name = election_commission_name;
	}

	public List<Party> getElection_parties() {
		return election_parties;
	}

	public void setElection_parties(List<Party> election_parties) {
		this.election_parties = election_parties;
	}

	
	public Election announce_election() {
		obj_election= obj_initiator.initiate_election();
		return obj_election;
	}
	public List<Party> get_party_details() {
		election_parties=obj_initiator.initiate_party_list();
		return election_parties;
	}
	public void get_constituency_details() {}
}
