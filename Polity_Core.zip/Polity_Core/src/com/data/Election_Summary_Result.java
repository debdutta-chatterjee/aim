package com.data;

public class Election_Summary_Result {
	
	List<Constituency> lst_const;
	
	
	
	
}
