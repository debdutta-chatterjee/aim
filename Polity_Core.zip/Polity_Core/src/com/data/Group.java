package com.data;

import java.util.HashMap;

public class Group {
	
	private String group_ID;
	private String group_name;
	private double group_relevance;
	private HashMap<Party,Double> group_support_to_party;
	private double group_unity_factor;
	private double group_vocal_level;
	
	
	public Group(String group_ID,String group_name, double group_relevance, HashMap<Party, Double> group_support_to_party,
			double group_unity_factor, double group_vocal_level) {
		super();
		this.group_name = group_name;
		this.group_relevance = group_relevance;
		this.group_support_to_party = group_support_to_party;
		this.group_unity_factor = group_unity_factor;
		this.group_vocal_level = group_vocal_level;
	}
	
	
	
	public String getGroup_ID() {
		return group_ID;
	}



	public void setGroup_ID(String group_ID) {
		this.group_ID = group_ID;
	}

	
	public String getGroup_name() {
		return group_name;
	}


	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}


	public double getGroup_relevance() {
		return group_relevance;
	}


	public void setGroup_relevance(double group_relevance) {
		this.group_relevance = group_relevance;
	}


	public HashMap<Party, Double> getGroup_support_to_party() {
		return group_support_to_party;
	}


	public void setGroup_support_to_party(HashMap<Party, Double> group_support_to_party) {
		this.group_support_to_party = group_support_to_party;
	}


	public double getGroup_unity_factor() {
		return group_unity_factor;
	}


	public void setGroup_unity_factor(double group_unity_factor) {
		this.group_unity_factor = group_unity_factor;
	}


	public double getGroup_vocal_level() {
		return group_vocal_level;
	}


	public void setGroup_vocal_level(double group_vocal_level) {
		this.group_vocal_level = group_vocal_level;
	}

	
}
