package com.data;

import java.util.HashMap;
import java.util.List;

import lombok.ToString;

@ToString
public class Party {
	
	private String party_id;
	private String party_name;
	private String party_symbol;
	
	private double party_acceptibility;
	private double party_image;
	private double party_financial_power;
	private double party_campaign_power;
	private double party_luck_factor;
	private double party_past_results;
	
	private List<Double> party_pro_Issues;
	private List<Double> party_pro_castes;
	private List<Double> party_pro_groups;
	private List<Double> party_support_profile;
	
	
	public Party(String party_id, String party_name, String party_symbol, double party_acceptibility,
			double party_image, double party_financial_power, double party_campaign_power, double party_luck_factor,
			double party_past_results, List<Double> party_pro_Issues, List<Double> party_pro_castes,
			List<Double> party_pro_groups, List<Double> party_support_profile) {
		super();
		this.party_id = party_id;
		this.party_name = party_name;
		this.party_symbol = party_symbol;
		this.party_acceptibility = party_acceptibility;
		this.party_image = party_image;
		this.party_financial_power = party_financial_power;
		this.party_campaign_power = party_campaign_power;
		this.party_luck_factor = party_luck_factor;
		this.party_past_results = party_past_results;
		this.party_pro_Issues = party_pro_Issues;
		this.party_pro_castes = party_pro_castes;
		this.party_pro_groups = party_pro_groups;
		this.party_support_profile = party_support_profile;
	}
	
	
	
	
	
	public String getParty_id() {
		return party_id;
	}
	public void setParty_id(String party_id) {
		this.party_id = party_id;
	}
	public String getParty_name() {
		return party_name;
	}
	public void setParty_name(String party_name) {
		this.party_name = party_name;
	}
	public String getParty_symbol() {
		return party_symbol;
	}
	public void setParty_symbol(String party_symbol) {
		this.party_symbol = party_symbol;
	}
	public List<Double> getParty_pro_Issues() {
		return party_pro_Issues;
	}
	public void setParty_pro_Issues(List<Double> party_pro_Issues) {
		this.party_pro_Issues = party_pro_Issues;
	}
	public List<Double> getParty_pro_castes() {
		return party_pro_castes;
	}
	public void setParty_pro_castes(List<Double> party_pro_castes) {
		this.party_pro_castes = party_pro_castes;
	}
	public List<Double> getParty_pro_groups() {
		return party_pro_groups;
	}
	public void setParty_pro_groups(List<Double> party_pro_groups) {
		this.party_pro_groups = party_pro_groups;
	}
	public List<Double> getParty_support_profile() {
		return party_support_profile;
	}
	public void setParty_support_profile(List<Double> party_support_profile) {
		this.party_support_profile = party_support_profile;
	}
	public double getParty_acceptibility() {
		return party_acceptibility;
	}
	public void setParty_acceptibility(double party_acceptibility) {
		this.party_acceptibility = party_acceptibility;
	}
	public double getParty_image() {
		return party_image;
	}
	public void setParty_image(double party_image) {
		this.party_image = party_image;
	}
	public double getParty_financial_power() {
		return party_financial_power;
	}
	public void setParty_financial_power(double party_financial_power) {
		this.party_financial_power = party_financial_power;
	}
	public double getParty_campaign_power() {
		return party_campaign_power;
	}
	public void setParty_campaign_power(double party_campaign_power) {
		this.party_campaign_power = party_campaign_power;
	}
	public double getParty_luck_factor() {
		return party_luck_factor;
	}
	public void setParty_luck_factor(double party_luck_factor) {
		this.party_luck_factor = party_luck_factor;
	}
	public double getParty_past_results() {
		return party_past_results;
	}
	public void setParty_past_results(double party_past_results) {
		this.party_past_results = party_past_results;
	}
	
	
}
