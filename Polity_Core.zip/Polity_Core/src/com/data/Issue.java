package com.data;

import java.util.HashMap;

public class Issue {
	private String issue_name;
	private double issue_relevance;
	private HashMap<Party,Double> issue_party_support;
	private HashMap<Caste,Double> issue_caste_influence;
	private HashMap<Electorate_Profile,Double> issue_electorate_influence;
	private double issue_vocal_level;
}
