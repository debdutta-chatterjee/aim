package com.data;

import java.util.HashMap;

public class Candidate {
	
	private String candidate_name;
	private Caste candidate_caste;
	private Constituency candidate_constituency_home;
	private Constituency candidate_constituency_conesting;
	private Electorate_Profile candidate_profile;
	private HashMap<Issue,Double> candidate_pro_Issues;
	private HashMap<Caste,Double> candidate_pro_castes;
	private HashMap<Group,Double> candidate_pro_groups;
	private HashMap<Party,Double> candidate_cross_support;
	private double candidate_acceptibility;
	private double candidate_image;
	private double candidate_financial_power;
	private double candidate_campaign_power;
	private double candidate_luck_factor;
	private double candidate_past_results;
	private double candidate_party_loyalty_factor;
	private Party candidate_party;
	
	//past win on constituency - symbol - opponent and margin
	
}
