package com.data;

import java.util.HashMap;

public class Caste {
	private String caste_ID;
	private String caste_name;
	private HashMap <Issue,Double> caste_issue_dist;
	private HashMap <Party,Double> caste_party_dist;
	private HashMap <Electorate_Profile,Double> caste_profile_dist;
	private double caste_vocal_level;
	
	//TO DO
	//define geography wise caste distribution pattern;
}
