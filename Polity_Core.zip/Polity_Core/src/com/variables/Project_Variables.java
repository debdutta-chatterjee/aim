package com.variables;

public final class Project_Variables {
	public final String ELECTION_TYPE="Assembly";
	public final int TOTAL_PARTY= 10;
	public final int TOTAL_CASTE=40;
	public final int TOTAL_ISSUE=25;
	public final int TOTAL_GROUP=17;
	public final int TOTAL_CONSTITUENCY=99;
	public final int TOTAL_PROFILE=29;
	public final int TOTAL_OTHERBIASES=29;
	
	//EC
	public final String EC_NAME= "TEST_EC_STATE";
	
	//Generic
	public final int RANDOM_LENGTH=8;
	
	//Election
	public final String ELECTION_ID_FORMAT="Election_ID_";
	public final String ELECTION_NAME_FORMAT="Election_Name_";
	
	//Group
	public final String GROUP_ID_FORMAT= "GROUP_ID_";
	public final String GROUP_NAME_FORMAT= "GROUP_Name_";
	public final double GROUP_UNITY_FACTOR_MIN=0.01;
	public final double GROUP_UNITY_FACTOR_MAX=0.97;
	public final double GROUP_VOCAL_LEVEL_MIN=0;
	public final double GROUP_VOCAL_LEVEL_MAX=10;
	public final double GROUP_RELEVANCE_MIN=0.01;
	public final double GROUP_RELEVANCE_MAX=0.81;
	public final double GROUP_SUPPORTINTENSITY_MINIMUM=0.1;
	public final double GROUP_SUPPORTINTENSITY_MAXIMUM=0.89;
	
	//Constituency
	public final int CONS_MIN_BOOTH=250;
	public final int CONS_MAX_BOOH=400;
	
	
	//Party
	public final String PARTY_NAME_FORMAT="";
	public final String PARTY_ID_FORMAT="PARTY_ID_";
	//TODO All party parameters to have separate min & max
	public final double PARTY_PARAM_MIN=0;
	public final double PARTY_PARAM_MAX=85;
	
	
	//Booth
	public final String Booth_ID_FORMAT="BoothID_";
	public final String Booth_NAME_FORMAT="Booth_";
	public final int ELECTORATE_PER_BOOTH_MIN=800;
	public final int ELECTORATE_PER_BOOTH_MAX=1500;
	public final double HIST_POLLING_MIN=45;
	public final double HIST_POLLING_MAX=95;
	public final double BOOTH_AREA_SQKM_MIN=100;
	public final double BOOTH_AREA_SQKM_MAX=200;
	
	//Mandate
	public final double HIST_POLLING_VARIANCE_MIN=-10;
	public final double HIST_POLLING_VARIANCE_MAX=10;
			
}
