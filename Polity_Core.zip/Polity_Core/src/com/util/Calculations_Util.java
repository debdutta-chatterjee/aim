package com.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.data.D;
import com.data.Party;

public class Calculations_Util {
	
	public int getmax_value_old(List<Integer> lst) {
		return Collections.max(lst).intValue();
	}
	
	
	public HashMap<Party, Integer> get_party_wise_results(List<Party> party_lst,List<Integer> lst_vote) {
		
		Map<Party,Integer> map_party_vote= new HashMap<Party,Integer>();
		Map<Party,Integer> sorted_map_party_vote= new HashMap<Party,Integer>();
		
		int index=0;
		
		for(Party party_obj:party_lst) {
			map_party_vote.put(party_obj, lst_vote.get(index));
			index++;
		}
		
		
		return map_party_vote.entrySet()
		  .stream()
		  .sorted(Map.Entry.comparingByValue())
		  .collect(Collectors.toMap(
				    Map.Entry::getKey, 
				    Map.Entry::getValue, 
				    (oldValue, newValue) -> oldValue, HashMap::new));		
	}
	
	
	public List<Party> getTops(int n,HashMap<Party,Integer>) {
        return map.
            values().
            stream().
            limit(n).
            reduce(new ArrayList<Party>(), (lhv, rhv) -> {
                lhv.addAll(rhv);
                return lhv;
            });
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
