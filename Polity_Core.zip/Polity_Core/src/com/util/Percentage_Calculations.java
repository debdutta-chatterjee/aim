package com.util;

import java.util.List;

public class Percentage_Calculations {
	public double getPercentage(double numerator, double denominator) {return 0;}
	public List<Double> getPercentage(List<Double> numerator, List<Double> denominator) {return null;}
}
